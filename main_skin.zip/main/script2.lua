-- Auto generated script file --
local crosshair1 = models.model.root.HUD:newText('crosshair1')
crosshair1:setPos(-37,-115)
local crosshair2 = models.model.root.HUD:newText('crosshair2')
crosshair2:setPos(-37,-125)
local crosshair3 = models.model.root.HUD:newText('crosshair3')
crosshair3:setPos(-37,-135)
local potato1000000000 = models.model.root.World:newText('potato1000000000')
potato1000000000:setPos(0,40)
potato1000000000:setBackground(true)
potato1000000000:setSeeThrough(true)
potato1000000000:setAlignment("CENTER")
potato1000000000:setScale(0.5)
potato1000000000:wrap(true)
local potato2000000000 = models.model.root.World:newText('potato2000000000')
potato2000000000:setPos(0,40)
potato2000000000:setBackground(true)
potato2000000000:setSeeThrough(true)
potato2000000000:setAlignment("CENTER")
potato2000000000:setScale(0.5)
potato2000000000:wrap(true)
potato2000000000:rot(0, 180, 0)
--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)
--re-enable the helmet item
vanilla_model.HELMET_ITEM:setVisible(true)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here
end

--tick event, called 20 times per second
function events.tick()
 test3 = player:getRot()
 test4 = models.model.root.World:getPos()
 test4_b = player:getPos()
 x1 = test4.x/16 -  test4_b.x
  y1 = test4.y/16 -  test4_b.y
   z1 = test4.z/16 -  test4_b.z
 test5 = models.model.root.World:getVisible()
 test5_b =  models.model.root.Head.HelmetItemPivot:getVisible()
  test5_c =models.model.root.HUD:getVisible()
 test6 = models.model.root.World:getScale()
 test7 = models.model.root.Head.HelmetItemPivot.group3.cube1:getVisible() -- if purple
 test8 = models.model.root.Head.HelmetItemPivot.group3.cube2:getVisible() -- if green
 test9 = models.model.root.Head.HelmetItemPivot.group3.cube3:getVisible() -- if blue
 test10 = models.model.root.Head.HelmetItemPivot.group3.cube4:getVisible() -- if red
 test11 = vanilla_model.ARMOR:getVisible()
potato1000000000:text("potato1000000000")
potato2000000000:text("potato1000000000")
crosshair1:text(test4.x/16)
crosshair2:text(test4.y/16)
crosshair3:text(test4.z/16)
if e == true then do
renderer:setOffsetCameraPivot(x1,y1,z1)
end
else do
renderer:setOffsetCameraPivot(0,0,0)
end
end
end



--render event, called every time your avatar is rendered
--it have two arguments, "delta" and "context"
--"delta" is the percentage between the last and the next tick (as a decimal value, 0.0 to 1.0)
--"context" is a string that tells from where this render event was called (the paperdoll, gui, player render, first person)
function events.render(delta, context)
  checkColor()
end

local mainPage = action_wheel:newPage()
local Page2 = action_wheel:newPage()
action_wheel:setPage(mainPage)
local action = mainPage:newAction()
    :title("Summon")
    :item("minecraft:ender_pearl")
    :hoverColor(0,1,0.75)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
 test2 = player:getRot()
   test = player:getPos()
   models.model.root.World:setPos(test.x*16,test.y*16,test.z*16)
models.model.root.World:setRot(0,-test3.y+180,0)
pings.tp()
end)
   local action = mainPage:newAction()
    :title("Hide")
    :item("minecraft:eye_of_ender")
    :hoverColor(0.1,0.1,0.5)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    if test5 == true  then do
     models.model.root.World:setVisible(false)
     pings.invis()
     end
     else if test5 == false then do
      models.model.root.World:setVisible(true)
      pings.vis()
      end
      end
      end
      end)
      :onRightClick(function()
      if test5_c == true  then do
models.model.root.HUD:setVisible(false)

     end
     else if test5_c == false then do
models.model.root.HUD:setVisible(true)


      end
      end
      end
      end)
       local action = mainPage:newAction()
    :title("Scale")
    :item("minecraft:potion")
    :hoverColor(1,0,0.8)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
  if test6.x > 1  then do
     models.model.root.World:setScale(1)
pings.big()
     end
     else if test6.x <= 1 then do
      models.model.root.World:setScale(0.5)
      pings.small()
      end
      end
      end
      end)
         :onRightClick(function()
  if test6.x < 1  then do
     models.model.root.World:setScale(1)
pings.big()
     end
     else if test6.x >= 1 then do
      models.model.root.World:setScale(2)
      pings.bigbig()
      end
      end
      end
      end)
        local action = mainPage:newAction()
    :title("Toggle Mushroom")
    :item("minecraft:red_mushroom")
    :hoverColor(0.5,0,0.75)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    if test5_b == true  then do
   models.model.root.Head.HelmetItemPivot:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2:setVisible(false)
       models.model.root.Skull.group2:setVisible(false)
pings.toggle_a()
     end
     else if test5_b == false then do
      models.model.root.Head.HelmetItemPivot:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2:setVisible(true)
       models.model.root.Skull.group2:setVisible(true)
pings.toggle_b()
      end
      end
      end
      end)
      previousColorVar = mainPage:newAction()
    :title("Previous mushroom color")
    :item("minecraft:red_concrete")
    :hoverColor(1,0,1)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    if test7 == true  then do
red()
       pings.red()
     end
     else if test10 == true then do
blue()
       pings.blue()

      end
          else if test9 == true then do
green()
pings.green()


      end
          else if test8 == true then do
purple()
pings.purple()

      end
      end
      end
      end
      end
end)

 nextColorVar = mainPage:newAction()
    :title("Next mushroom color")
    :item("minecraft:lime_concrete")
    :hoverColor(1,0,1)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    if test7 == true  then do
green()
       pings.green()
     end
     else if test8 == true then do
blue()
       pings.blue()

      end
          else if test9 == true then do
red()
pings.red()


      end
          else if test10 == true then do
purple()
pings.purple()

      end
      end
      end
      end
      end
end)
   local action = mainPage:newAction()
    :title("Armor toggle")
    :item("minecraft:iron_chestplate")
    :hoverColor(1,1,1)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    if test11 == true then do
    vanilla_model.ARMOR:setVisible(false)
    pings.armorToggle_a()
    end
    else if test11 == false then do
    vanilla_model.ARMOR:setVisible(true)
    pings.armorToggle_b()
    end
    end
    end
    end)
 local action = mainPage:newAction()
    :title("next page")
    :item("gravity_api:gravity_changer_east")
    :hoverColor(1,0,0)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    action_wheel:setPage(Page2)
    end)
     local action = Page2:newAction()
    :title("go back")
    :item("gravity_api:gravity_changer_west")
    :hoverColor(1,0,0)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
    action_wheel:setPage(mainPage)
    end)
       local action = Page2:newAction()
    :title("sit")
    :item("minecraft:grass_block")
    :hoverColor(0,1,0)
    -- the `onLeftClick` function just sets the Action's`leftClick` field
    :onLeftClick(function()
animations.model.sit:play()
renderer:setOffsetCameraPivot(0, -1, 0)
pings.sit()
end)
 :onRightClick(function()
 animations:stopAll()
  renderer:setOffsetCameraPivot(0, 0, 0)
 pings.unsit()
    end)
  local action = Page2:newAction()
       :title("disabled")
    :toggleTitle("enabled")
    :item("red_wool")
    :toggleItem("green_wool")
    :onToggle(function()
  if not e == true  then do  e = true
  models.model.root.World:setVisible(false)
  end
  else if e == true then do e = false
models.model.root.World:setVisible(true)
end
end
end
end)







function green()
    models.model.root.Head.HelmetItemPivot.group3.cube1:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube1:setVisible(false)
         models.model.root.Skull.group2.cube1:setVisible(false)
             models.model.root.Head.HelmetItemPivot.group3.cube2:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube2:setVisible(true)
         models.model.root.Skull.group2.cube2:setVisible(true)
             models.model.root.Head.HelmetItemPivot.group3.cube3:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube3:setVisible(false)
         models.model.root.Skull.group2.cube3:setVisible(false)

       end
function blue()

             models.model.root.Head.HelmetItemPivot.group3.cube2:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube2:setVisible(false)
         models.model.root.Skull.group2.cube2:setVisible(false)
             models.model.root.Head.HelmetItemPivot.group3.cube3:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube3:setVisible(true)
         models.model.root.Skull.group2.cube3:setVisible(true)
             models.model.root.Head.HelmetItemPivot.group3.cube4:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube4:setVisible(false)  models.model.root.Skull.group2.cube4:setVisible(false)
       end
function red()
     models.model.root.Head.HelmetItemPivot.group3.cube1:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube1:setVisible(false)  models.model.root.Skull.group2.cube1:setVisible(false)

             models.model.root.Head.HelmetItemPivot.group3.cube3:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube3:setVisible(false)  models.model.root.Skull.group2.cube3:setVisible(false)
             models.model.root.Head.HelmetItemPivot.group3.cube4:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube4:setVisible(true)
       models.model.root.Skull.group2.cube4:setVisible(true)
       end
       function purple()
             models.model.root.Head.HelmetItemPivot.group3.cube1:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube1:setVisible(true)
         models.model.root.Skull.group2.cube1:setVisible(true)
             models.model.root.Head.HelmetItemPivot.group3.cube2:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube2:setVisible(false)
         models.model.root.Skull.group2.cube2:setVisible(false)

             models.model.root.Head.HelmetItemPivot.group3.cube4:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2.group4.cube4:setVisible(false)  models.model.root.Skull.group2.cube4:setVisible(false)
       end
function pings.green()
green()
       end
function pings.blue()
blue()
       end
function pings.red()
red()
       end
function pings.purple()
 purple()
       end
function pings.toggle_a()
   models.model.root.Head.HelmetItemPivot:setVisible(false)
       models.model.root.World.root2.Hea3.HelmetItemPivot2:setVisible(false)
       models.model.root.Skull.group2:setVisible(false)
       end
       function pings.toggle_b()
             models.model.root.Head.HelmetItemPivot:setVisible(true)
       models.model.root.World.root2.Hea3.HelmetItemPivot2:setVisible(true)
       models.model.root.Skull.group2:setVisible(true)
       end
function pings.big()
 models.model.root.World:setScale(1)
 end
 function pings.bigbig()
 models.model.root.World:setScale(2)
 end
 function pings.small()
 models.model.root.World:setScale(0.5)
 end
function pings.invis()
   models.model.root.World:setVisible(false)
   end
   function pings.vis()
   models.model.root.World:setVisible(true)
   end
   function pings.tp()
   test2 = player:getRot()
   test = player:getPos()
   models.model.root.World:setPos(test.x*16,test.y*16,test.z*16)
models.model.root.World:setRot(0,-test3.y+180,0)
end

function checkColor()

  if test7 == true then nextColorVar:item("minecraft:lime_concrete") previousColorVar:item("minecraft:red_concrete")
  nextColorVar:hoverColor(0,1,0) previousColorVar:hoverColor(1,0,0)end

  if test8 == true then nextColorVar:item("minecraft:light_blue_concrete") previousColorVar:item("minecraft:purple_concrete")
  nextColorVar:hoverColor(0,0,1) previousColorVar:hoverColor(1,0,1)end
  if test9 == true then nextColorVar:item("minecraft:red_concrete") previousColorVar:item("minecraft:lime_concrete")
  nextColorVar:hoverColor(1,0,0) previousColorVar:hoverColor(0,1,0)end
  if test10 == true then nextColorVar:item("minecraft:purple_concrete") previousColorVar:item("minecraft:light_blue_concrete")
  nextColorVar:hoverColor(1,0,1) previousColorVar:hoverColor(0,0,1)end

end

function pings.armorToggle_a()
    vanilla_model.ARMOR:setVisible(false)
end
function pings.armorToggle_b()
    vanilla_model.ARMOR:setVisible(true)
end

function pings.sit()
animations.model.sit:play()
end
function pings.unsit()
 animations:stopAll()
end


